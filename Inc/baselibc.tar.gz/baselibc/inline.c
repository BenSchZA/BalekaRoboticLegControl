// Make an externally visible symbol out of inlined functions
#define __extern_inline
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
